<h1 align="center">
   music app
</h1>

<div align="center">

    
</div>

## TECHNOLOGY USED

* ### [React.js](https://reactjs.org/)
    * ###### [react-router](https://github.com/ReactTraining/react-router#readme)
    * ###### [react-redux](https://react-redux.js.org/)
    * ###### [material-ui/core](https://www.npmjs.com/package/@material-ui/core)
    * ###### [material-ui/icons](https://www.npmjs.com/package/@material-ui/icons)
    * ###### [context API](https://reactjs.org/docs/context.html)
    * ###### [scss](https://sass-lang.com/)
   

## Attribution
    
[API call][music] https://www.songsterr.com/a/wa/api/
