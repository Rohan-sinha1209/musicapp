
class app extends React.Component{
    constructor()
    {
        super();
        this.state={
            users:null
            
        }
    }
    componentDidMount()
    {
        fetch('https://www.songsterr.com/a/wa/api/').then((resp)=>{
            resp.json().then((result)=>{
            console.warn(result)
        })
    })
    }
}
