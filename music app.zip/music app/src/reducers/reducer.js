import {combineReducers} from "redux";
import musicReducer from "./musicReducer";

const reducers = combineReducers({
    musicReducer,
});

export default reducers;